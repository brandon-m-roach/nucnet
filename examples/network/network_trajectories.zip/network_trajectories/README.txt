

trajectory zone 161 has the temperature increase too rapid, and the code doesn't know how to handle it.

file zonetrajectory161_2 starts at 2e-1sec. that is after the "problematic" slope. However, there should be a better solution to solve this problem.

